﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace GameApplication
{
    public partial class MainForm : Form
    {
        private HuffmanTree huffmanTree;
        private Random random;
        private Random random2;
        public static string user= "";
        public static string answer_status = "";
        public static string answer_status2 = "";
        public static string SetValueForText2 = "";
        public MainForm()
        {
            InitializeComponent();

            user = login.SetValueForText1;
            encodedTextBox.Multiline = true;
            encodedTextBox.ScrollBars = ScrollBars.Vertical;
            encodedTextBox2.Multiline = true;
            encodedTextBox2.ScrollBars = ScrollBars.Vertical;
            label7.Text = "";
            label8.Text = "";
            random = new Random();
            random2 = new Random();
            con = new SqlConnection("Data Source=LAPTOP-ATG56U89;Initial Catalog=GameApp;Integrated Security=True");
        }
        SqlConnection con;
        SqlCommand cmd;

        private string GenerateRandomString(int length)
        {
            const string chars = "abcdefghijklmnopqrstuvwxyz1234";
            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < length; i++)
            {
                int index = random.Next(chars.Length);
                sb.Append(chars[index]);
            }

            return sb.ToString();


        }
        private string GenerateRandomBinaryString(int length)
        {
            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < length; i++)
            {
                int bit = random2.Next(2); // Generate a random bit (0 or 1)
                sb.Append(bit);
            }

            return sb.ToString();
        }


        void EncodeButton_Click(object sender, EventArgs e)
        {
            string text = inputTextBox.Text;
            if (string.IsNullOrEmpty(text))
            {
                MessageBox.Show("Please enter a text to encode.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string answertext= txt_answer.Text;
            if (string.IsNullOrEmpty(answertext))
            {
                label7.Text = "Answer cannot be empty";
                return;
            }
            string tString = txt_answer.Text;
            if (tString.Trim() == "") return;
            for (int i = 0; i < tString.Length; i++)
            {
                if (!char.IsNumber(tString[i]))
                {
                    label7.Text = "Please enter a valid answer";
                    return;
                }

            }

            huffmanTree = new HuffmanTree(text);
            Dictionary<char, string> encodingTable = huffmanTree.GetEncodingTable();

            StringBuilder encodedText = new StringBuilder();
            foreach (char c in text)
            {
                encodedText.Append(encodingTable[c]);
            }

            encodedTextBox.Text = encodedText.ToString();

            if(txt_answer.Text==encodedTextBox.Text)
            {
                answer_status = "Correct";
                MessageBox.Show(this, "The answer is correct", "Information", MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
            else
            {
                answer_status = "wrong";
                MessageBox.Show(this, "The answer is wrong", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }

            string playerName,random_string,answer;
            playerName = user;
            random_string = inputTextBox.Text;
            answer = txt_answer.Text;
            

            try
           {
                con.Open();
                cmd = new SqlCommand("Insert into Encode values ( @b, @c, @d,@e)", con);
                cmd.Parameters.AddWithValue("b", random_string);
                cmd.Parameters.AddWithValue("c", answer);
                cmd.Parameters.AddWithValue("d", answer_status);
                cmd.Parameters.AddWithValue("e", playerName);



                 int i = cmd.ExecuteNonQuery();
                
		        if (i == 1)
                    MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                   MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
                cmd.Dispose();
            }
            catch (SqlException ex)
            {
               
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
         

          
        }

        private void DecodeButton_Click(object sender, EventArgs e)
        {

          
        }

        private void btn_submit_Click(object sender, EventArgs e)
        {
            int length = random.Next(1, 30); // Generate a random length between 5 and 15 characters
            string randomString = GenerateRandomString(length);
            inputTextBox.Text = randomString;
        }

        private void btn_submit2_Click(object sender, EventArgs e)
        {
            int length = random.Next(1, 30); // Generate a random length between 5 and 15 characters
            string randomBinaryString = GenerateRandomBinaryString(length);
            inputTextBox2.Text = randomBinaryString;
        }

        private void encodedButton2_Click(object sender, EventArgs e)
        {
            string text = inputTextBox2.Text;
            if (string.IsNullOrEmpty(text))
            {
                MessageBox.Show("Please enter a text to decode.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string answertext = txt_answer2.Text;
            if (string.IsNullOrEmpty(answertext))
            {
                label8.Text = "Please enter a valid answer";
                return;
            }
            
                huffmanTree = new HuffmanTree(text);
            Dictionary<char, string> encodingTable = huffmanTree.GetEncodingTable();

            StringBuilder encodedText = new StringBuilder();
            foreach (char c in text)
            {
                encodedText.Append(encodingTable[c]);
            }

            encodedTextBox2.Text = encodedText.ToString();
            if (txt_answer2.Text == encodedTextBox2.Text)
            {

                answer_status2 = "correct";
                MessageBox.Show(this, "The answer is correct", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else
            {
                answer_status2 = "wrong";
                MessageBox.Show(this, "The answer is wrong", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }

            string playerName, random_string, answer;
            random_string = inputTextBox2.Text;
            answer = txt_answer2.Text;
            playerName = user;
            

            try
            {
                con.Open();
                cmd = new SqlCommand("Insert into Decode values ( @b, @c, @d,@e)", con);
         
                cmd.Parameters.AddWithValue("b", random_string);
                cmd.Parameters.AddWithValue("c", answer);
                cmd.Parameters.AddWithValue("d", answer_status2);
                cmd.Parameters.AddWithValue("e", playerName);




                int i = cmd.ExecuteNonQuery();

                if (i == 1)
                    MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                con.Close();
                cmd.Dispose();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void decodeButton2_Click(object sender, EventArgs e)
        {
           

        }

        private string HuffmanDecode(string binaryString)
        {
            StringBuilder decodedText = new StringBuilder();

            Node currentNode = huffmanTree.RootNode; // Access the root node of the Huffman tree

            foreach (char bit in binaryString)
            {
                if (currentNode == null)
                {
                    // Handle the case where decoding failed or the binary string is invalid
                    // You can choose to throw an exception, return an error message, or handle it in a way suitable for your application
                    // For example, you can return an empty string as an error result
                    return string.Empty;
                }

                if (bit == '0')
                {
                    currentNode = currentNode.LeftChild;
                }
                else if (bit == '1')
                {
                    currentNode = currentNode.RightChild;
                }

                if (currentNode != null && currentNode.IsLeafNode())
                {
                    char character = currentNode.Character;
                    decodedText.Append(character);
                }
            }

            return decodedText.ToString();
        }

        private void encodedTextBox_TextChanged(object sender, EventArgs e)
        {       
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SetValueForText2 = user;
            this.Hide();
            MainForm2 mainform = new MainForm2();
            mainform.Show();
        }

        private void txt_answer2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void lbl_result2_Click(object sender, EventArgs e)
        {
                    }

        private void button2_Click(object sender, EventArgs e)
        {
            SetValueForText2 = user;
            this.Hide();
            MainForm2 mainform = new MainForm2();
            mainform.Show();
        }
    }




    public class HuffmanTree
    {
        private readonly Dictionary<char, int> characterFrequencies;
        private readonly Node rootNode;
        public Node RootNode { get { return rootNode; } }
        public Dictionary<string, char> EncodingTable { get; }


        public HuffmanTree(string text)
        {
            characterFrequencies = GetCharacterFrequencies(text);
            rootNode = BuildTree();
        }

        public Dictionary<char, string> GetEncodingTable()
        {
            Dictionary<char, string> encodingTable = new Dictionary<char, string>();
            TraverseTree(rootNode, "", encodingTable);
            return encodingTable;
        }
        public string Decode(string encodedText)
        {
            StringBuilder decodedText = new StringBuilder();
            Node currentNode = rootNode;

            foreach (char bit in encodedText)
            {
                if (bit == '0')
                {
                    currentNode = currentNode.LeftChild;
                }
                else if (bit == '1')
                {
                    currentNode = currentNode.RightChild;
                }

                if (currentNode.IsLeafNode())
                {
                    decodedText.Append(currentNode.Character);
                    currentNode = rootNode;
                }
            }

            return decodedText.ToString();
        }
        private Dictionary<char, int> GetCharacterFrequencies(string text)
        {
            Dictionary<char, int> frequencies = new Dictionary<char, int>();

            foreach (char c in text)
            {
                if (frequencies.ContainsKey(c))
                {
                    frequencies[c]++;
                }
                else
                {
                    frequencies[c] = 1;
                }
            }

            return frequencies;
        }
        private Node BuildTree()
        {
            PriorityQueue<Node> priorityQueue = new PriorityQueue<Node>(characterFrequencies.Count);

            foreach (KeyValuePair<char, int> kvp in characterFrequencies)
            {
                Node leafNode = new Node(kvp.Key, kvp.Value);
                priorityQueue.Enqueue(leafNode);
            }

            while (priorityQueue.Count > 1)
            {
                Node leftChild = priorityQueue.Dequeue();
                Node rightChild = priorityQueue.Dequeue();
                Node parent = new Node(leftChild, rightChild);
                priorityQueue.Enqueue(parent);
            }

            return priorityQueue.Dequeue();
        }
        
        private void TraverseTree(Node node, string currentCode, Dictionary<char, string> encodingTable)
        {
            if (node.IsLeafNode())
            {
                encodingTable[node.Character] = currentCode;
            }
            else
            {
                TraverseTree(node.LeftChild, currentCode + "0", encodingTable);
                TraverseTree(node.RightChild, currentCode + "1", encodingTable);
            }
        }


    }
}
public class Node : IComparable<Node>
{
    public char Character { get; set; }
    public int Frequency { get; set; }
    public Node LeftChild { get; set; }
    public Node RightChild { get; set; }

    public Node(char character, int frequency)
    {
        Character = character;
        Frequency = frequency;
    }

    public Node(Node leftChild, Node rightChild)
    {
        Character = '\0';
        Frequency = leftChild.Frequency + rightChild.Frequency;
        LeftChild = leftChild;
        RightChild = rightChild;
    }

    public bool IsLeafNode()
    {
        return LeftChild == null && RightChild == null;
    }

    public int CompareTo(Node other)
    {
        return Frequency.CompareTo(other.Frequency);
    }
}

public class PriorityQueue<T> where T : IComparable<T>
{
    private readonly List<T> items;

    public int Count => items.Count;

    public PriorityQueue(int capacity)
    {
        items = new List<T>(capacity);
    }

    public void Enqueue(T item)
    {
        items.Add(item);
        int i = items.Count - 1;

        while (i > 0 && items[i].CompareTo(items[(i - 1) / 2]) < 0)
        {
            int parentIndex = (i - 1) / 2;
            Swap(i, parentIndex);
            i = parentIndex;
        }
    }

    public T Dequeue()
    {
        if (items.Count == 0)
        {
            throw new InvalidOperationException("Priority queue is empty.");
        }

        T item = items[0];
        items[0] = items[items.Count - 1];
        items.RemoveAt(items.Count - 1);
        int i = 0;

        while (true)
        {
            int leftChildIndex = 2 * i + 1;
            int rightChildIndex = 2 * i + 2;

            if (leftChildIndex >= items.Count)
            {
                break;
            }

            int smallerChildIndex = leftChildIndex;

            if (rightChildIndex < items.Count && items[rightChildIndex].CompareTo(items[leftChildIndex]) < 0)
            {
                smallerChildIndex = rightChildIndex;
            }

            if (items[i].CompareTo(items[smallerChildIndex]) <= 0)
            {
                break;
            }

            Swap(i, smallerChildIndex);
            i = smallerChildIndex;
        }

        return item;
    }

    private void Swap(int i, int j)
    {
        T temp = items[i];
        items[i] = items[j];
        items[j] = temp;
    }
}
