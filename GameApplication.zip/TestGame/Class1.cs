﻿using NUnit.Framework;
using System;

namespace GameApplication.Tests
{
    [TestFixture]
    public class MainFormTests
    {
        private MainForm mainForm;

        [SetUp]
        public void SetUp()
        {
            mainForm = new MainForm();
        }

        [Test]
        public void EncodeButton_Click_InputEmpty_ShowWarningMessageBox()
        {
            // Arrange
            mainForm.inputTextBox.Text = "";

            // Act
            mainForm.EncodeButton_Click(null, EventArgs.Empty);

            // Assert
            MessageBoxAsserter.AssertMessageBoxShown("Please enter a text to encode.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        [Test]
        public void EncodeButton_Click_InputNotEmpty_EncodeTextAndCheckAnswer()
        {
            // Arrange
            mainForm.inputTextBox.Text = "hello";
            mainForm.txt_answer.Text = "110011";
            mainForm.encodedTextBox.Text = "";

            // Act
            mainForm.EncodeButton_Click(null, EventArgs.Empty);

            // Assert
            Assert.AreEqual("110011", mainForm.encodedTextBox.Text);
            Assert.AreEqual("The answer is correct", mainForm.lbl_result.Text);
        }

        [Test]
        public void EncodeButton_Click_SaveDataSuccessfully_ShowSuccessMessageBox()
        {
            // Arrange
            mainForm.inputTextBox.Text = "hello";
            mainForm.txt_answer.Text = "110011";
            mainForm.encodedTextBox.Text = "";
            mainForm.con.ConnectionString = "valid_connection_string";

            // Act
            mainForm.EncodeButton_Click(null, EventArgs.Empty);

            // Assert
            MessageBoxAsserter.AssertMessageBoxShown("Data save Successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        [Test]
        public void EncodeButton_Click_SaveDataFailed_ShowErrorMessageBox()
        {
            // Arrange
            mainForm.inputTextBox.Text = "hello";
            mainForm.txt_answer.Text = "110011";
            mainForm.encodedTextBox.Text = "";
            mainForm.con.ConnectionString = "invalid_connection_string";

            // Act
            mainForm.EncodeButton_Click(null, EventArgs.Empty);

            // Assert
            MessageBoxAsserter.AssertMessageBoxShown("Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        // Add more unit tests for other methods and scenarios as needed

        private static class MessageBoxAsserter
        {
            public static void AssertMessageBoxShown(string expectedMessage, string expectedCaption, MessageBoxButtons expectedButtons, MessageBoxIcon expectedIcon)
            {
                // Logic to assert the expected message box shown
            }
        }
    }
}

